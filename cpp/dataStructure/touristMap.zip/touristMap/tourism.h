#ifndef TOURISM_H
#define TOURISM_H

void createGraph();
void getSpotInfo();
void travelPath();
void findShortPath();
void designPath();

#endif