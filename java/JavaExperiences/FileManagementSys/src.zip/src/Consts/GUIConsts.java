package Consts;

import javax.swing.*;
import java.awt.*;

public interface GUIConsts {
    public static final Color BG_COLOR = new Color(128, 128, 128);
    public static final int WIDTH = 800, HEIGHT = 800;
}
