package consts;

public interface FILE_CONST {
    String DOWNLOAD_DIR = "D:/Downloads/";
    String SERVER_DIR = "D:/";
}
