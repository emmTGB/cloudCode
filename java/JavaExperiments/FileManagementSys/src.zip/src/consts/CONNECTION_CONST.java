package consts;

public interface CONNECTION_CONST {
    String SQL_HOST = "10.78.125.241";
    //    String SQL_HOST = "127.0.0.1";
    String SQL_USER = "byeol";
    String SQL_PASS = "123456";
    String DATABASE = "forJavaExperiment";
    String USER_TABLE = "users";
    String DOC_TABLE = "docs";
    String ERR_FILE_NOT_FOUND = "FileNotFound";
    String MSG_READY_TO_DOWNLOAD = "ReadyToDownload";
    String SERVER_HOST = "10.78.125.241";
    int SERVER_PORT = 3939;
}
