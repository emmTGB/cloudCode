package consts;

public interface CONNECTION_CONST {
    String SQL_HOST = "202.189.5.24";
    //    String SQL_HOST = "10.78.125.241";
    //    String SQL_HOST = "192.168.137.170";
    //    String SQL_HOST = "127.0.0.1";
    String SQL_USER = "byeol";
    String SQL_PASS = "123456";
    String DATABASE = "forJavaExperiment";
    String USER_TABLE = "users";
    String DOC_TABLE = "docs";
    String ERR_FILE_NOT_FOUND = "FileNotFound";
    String MSG_READY_TO_DOWNLOAD = "ReadyToDownload";
    String SERVER_HOST = "202.189.5.24";
    //    String SERVER_HOST = "10.78.125.241";
    //    String SERVER_HOST = "192.168.137.170";
    //    String SERVER_HOST = "127.0.0.1";
    int CLIENT_PORT = 62511;
    //    int SQL_PORT = 3306;
    int SQL_PORT = 53232;
}
