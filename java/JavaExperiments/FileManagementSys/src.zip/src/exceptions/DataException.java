package exceptions;

public class DataException extends MyException {
    public DataException(String exceptionMsg) {
        super(exceptionMsg);
    }
}
