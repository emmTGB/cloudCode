package exceptions;

import consts.FILE_CONST;

public class DataException extends MyException {
    public DataException(String exceptionMsg) {
        super(exceptionMsg);
    }
}
