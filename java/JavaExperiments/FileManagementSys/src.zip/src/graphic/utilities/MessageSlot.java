package graphic.utilities;

public interface MessageSlot {
    void confirmTriggered();

    void cancelTriggered();
}
