package sum_and_aver;

import javax.swing.*;

public class Frame {
    public static void main(String[] args) {
        JFrame jFrame = new JFrame();
        JPanel jPanel = new JPanel();
        JTextArea jTextArea = new JTextArea();
        JTextField sumField = new JTextField();
        JTextField averField = new JTextField();
        JLabel sumLabel = new JLabel("sum");
        JLabel averLabel = new JLabel("average");
    }
}
