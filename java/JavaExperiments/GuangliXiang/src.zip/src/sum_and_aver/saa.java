package sum_and_aver;

import javax.swing.*;

public class saa {
    private JTextArea textArea1;
    private JPanel panel1;
    private JTextField textField1;
    private JTextField textField2;
}
