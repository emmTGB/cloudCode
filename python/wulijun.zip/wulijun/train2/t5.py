import math

a = int(input())
b = int(input())

ans = math.ceil(a * a / (b * b))
print(f"{ans}")