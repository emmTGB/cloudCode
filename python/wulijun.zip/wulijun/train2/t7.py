import math
a = eval(input())

if a < 0:
    a = -a

print(a)