def fabs(x):
    ret = float(x)
    if ret < 0:
        ret = -ret
    return ret