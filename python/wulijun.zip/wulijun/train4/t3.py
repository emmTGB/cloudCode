def hi_name(name:str):
    print("Hello, " + name + "!")
    return