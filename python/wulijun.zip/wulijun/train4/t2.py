def hi():
    return "hi"

if __name__ == "__main__":
    print(hi())