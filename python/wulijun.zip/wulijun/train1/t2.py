a = eval(input())
b = eval(input())

ans = a * b
print(f"{ans}")