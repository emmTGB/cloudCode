def solve(a,b):
    # 在此处输入你的代码
    print(a+b)
    print(a-b)
    print(a*b)
    

if __name__ == '__main__':
    a = int(input())  # 输入转为整数
    b = int(input())  # 输入转为整数
    solve(a,b)        # 调用你定义的函数进行数学运算
